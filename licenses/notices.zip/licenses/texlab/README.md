# texlab 5.26.0

RuneTeX distributes the unmodified official `texlab-x86_64-windows.zip`
executable from texlab 5.26.0 as `tools/texlab/texlab.exe`. The executable runs
as a separate Language Server Protocol process. Its GPL-3.0 license text is
provided in [LICENSE](LICENSE).

## Source downloads for this executable

- [Original release and binary assets](https://github.com/latex-lsp/texlab/releases/tag/v5.26.0)
- [Source archive, pinned to release commit 45c3ced6790b508a12a2aab1938e58023173017e](https://codeload.github.com/latex-lsp/texlab/zip/45c3ced6790b508a12a2aab1938e58023173017e)
- [Browse that exact source](https://github.com/latex-lsp/texlab/tree/45c3ced6790b508a12a2aab1938e58023173017e)
- [Original dependency lockfile](https://github.com/latex-lsp/texlab/blob/45c3ced6790b508a12a2aab1938e58023173017e/Cargo.lock)
- [Original source build instructions](https://github.com/latex-lsp/texlab/blob/45c3ced6790b508a12a2aab1938e58023173017e/README.md#building-from-source)
- [Original release build workflow](https://github.com/latex-lsp/texlab/blob/45c3ced6790b508a12a2aab1938e58023173017e/.github/workflows/publish.yml)

The release tag was resolved to the full commit above. The downloaded
source archive and the packaged executable's official ZIP were checked.
Their SHA-256 values, together with the executable and license hashes, are
recorded in [inventory.json](inventory.json).

The original source archive includes the workspace crates, dependency
lockfile, README and GPL text. The original release workflow is also copied
as [UPSTREAM-BUILD.yml](UPSTREAM-BUILD.yml), because GitHub's source export
omits that workflow. [SOURCE-Cargo.lock](SOURCE-Cargo.lock) is a verbatim copy
of the matching lockfile. [source-dependencies.json](source-dependencies.json)
provides exact registry source-archive URLs and the original lockfile's
SHA-256 checksums. That index contains all lockfile platforms and development
entries; the Windows dependency copyright/license inventory is in
[dependencies/INDEX.md](dependencies/INDEX.md). It preserves the original
license and notice texts for 165 registry packages in texlab's activated
Windows normal/build dependency graph. The 23 workspace crates share the
upstream texlab source and GPL text linked above.

To regenerate that inventory after fetching the exact source and its locked
registry packages, run from the RuneTeX repository:

```powershell
. .\scripts\NoticeBundle.ps1
$noticeRoot = Get-NoticeRoot -AllowWorkingChanges
python scripts/Generate-RustNotices.py --manifest-path .deps/texlab-source/texlab-45c3ced6790b508a12a2aab1938e58023173017e/Cargo.toml --package texlab --output (Join-Path $noticeRoot 'texlab\dependencies') --skip-toolchain
```

Add `--check` to verify the checked-in notices against the same source. The
`--skip-toolchain` switch records no compiler identity for this third-party
binary: its compiler was selected by upstream's `stable` workflow.

## Building the corresponding source

Extract the pinned source archive. On Windows, install Rust and the MSVC C++
build tools and run this command from the extracted workspace:

```powershell
cargo build --target x86_64-pc-windows-msvc --all-features --release --locked
```

This is the command in the upstream Windows release workflow. Cargo uses
the included `Cargo.lock` to retrieve the matching dependency sources. The
upstream workflow selects the stable Rust toolchain and the
`windows-latest` runner; it does not pin an exact compiler or runner image.
These instructions therefore describe how to build the corresponding
source, without promising a byte-for-byte reproduction of the official EXE.
RuneTeX has made no source changes to texlab.

## Attribution

texlab is developed by Eric Förster, Patrick Förster and texlab
contributors. Individual source files and dependency notices retain their
respective copyright statements. Keep these notices, the GPL text and the
source-download directions with redistributed copies of this executable.

The source links above are the original upstream locations for the exact
bundled version. Release publishers must preserve clear access directions
and the source availability required by the applicable license when moving
or mirroring their release.
