# Embedded Windows fonts

The Windows RuneTeX applications enable Rune's `embedded-fonts` feature.
For native builds at Rune commit
`a05683be96cbd725ca1fbb34810368309ac534a5`, the embedded fallback fonts are
Inter Regular, Medium and SemiBold. The font name tables identify version
`4.001;git-9221beed3`.

- Copyright 2016 The Inter Project Authors
- Designer: Rasmus Andersson
- License: SIL Open Font License 1.1; full copyright and license text in
  [Inter-LICENSE.txt](Inter-LICENSE.txt)
- [Original Inter project](https://github.com/rsms/inter)
- [Exact Rune native font selection](https://github.com/anomalyco/rune/blob/a05683be96cbd725ca1fbb34810368309ac534a5/crates/rune/src/text/default_fonts.rs)
- [Exact supplied font assets and license](https://github.com/anomalyco/rune/tree/a05683be96cbd725ca1fbb34810368309ac534a5/crates/rune/assets)

[inventory.json](inventory.json) identifies each embedded font by SHA-256,
size and an immutable download link. This directory contains notices and
source references; the three font files are embedded in the executables.

IBM Plex Mono is in Rune's web/test font assets, but is not embedded by this
native Windows feature selection. User-selected fonts such as Segoe UI,
Cascadia Code and Malgun Gothic are loaded from the installed system and
are not copied into the installer.
