@echo on
setlocal enabledelayedexpansion

CFLAGS="${CFLAGS} -O3"
CXXFLAGS="${CXXFLAGS} -O3"

if [%PKG_NAME%] == [pcre2] (
    REM first without static libs...
    set "CF_BUILD_STATIC_LIBS=OFF"
) else (
    REM ... then with
    set "CF_BUILD_STATIC_LIBS=ON"
)

mkdir "%SRC_DIR%"\build_cmake
pushd "%SRC_DIR%"\build_cmake
cmake %CMAKE_ARGS% ^
    -DBUILD_SHARED_LIBS=ON ^
    -DBUILD_STATIC_LIBS=!CF_BUILD_STATIC_LIBS! ^
    -DCMAKE_BUILD_TYPE=release ^
    -DCMAKE_INSTALL_PREFIX=%LIBRARY_PREFIX% ^
    -DPCRE2_SUPPORT_JIT=ON ^
    -DPCRE2_BUILD_PCRE2_16=ON ^
    -DPCRE2_BUILD_PCRE2_32=ON ^
    -GNinja ^
    ..
if errorlevel 1 exit 1

cmake --build .
if errorlevel 1 exit 1
sed -ie "s/\$<TARGET_FILE:pcre2test>/pcre2test.exe/" pcre2_test.bat
cp -r ..\testdata .
if errorlevel 1 exit 1

if not "%CONDA_BUILD_CROSS_COMPILATION%" == "1" (
  ctest --rerun-failed --output-on-failure
  if errorlevel 1 exit 1
)

cmake --install .
if errorlevel 1 exit 1

popd
rmdir /s /q "%SRC_DIR%"\build_cmake
