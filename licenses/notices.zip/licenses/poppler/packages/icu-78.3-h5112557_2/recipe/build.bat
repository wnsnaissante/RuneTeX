SETLOCAL EnableDelayedExpansion

:: Merge the extra ICU data source into source\data, overwriting any
:: placeholder project files that already shipped in the sources tarball.
:: rattler-build's target_directory extraction refuses to overwrite existing
:: files (unlike conda-build's folder key, which merges silently), so the
:: data.zip archive is extracted to %SRC_DIR%\icu-data-src instead and
:: merged here manually, before source\data is touched by anything else.
xcopy /E /Y /I "%SRC_DIR%\icu-data-src" "%SRC_DIR%\source\data"
if errorlevel 1 exit 1

cd source

:: Remove all instances of /W4 from configure.
:: They get passed to the linker and confuse it.
:: Given that we aren't interested in warnings anyway
:: remove it. I could have used a patch but this seemed
:: more 'upgrade friendly'
sed "s~ /W4~~g" configure > configure.new
move configure.new configure

:: This seems to be required - not sure why but
:: rc.exe gets confused with the '/' form of slashes
set MSYS_RC_MODE=1


:: This directory is needed during the install process but isn't created by the scripts.
mkdir data\out\tmp

echo "build - %build_platform% - %BUILD_PLATFORM%"
cd ..

echo export build_platform=%build_platform%  > build.sh
echo export target_platform=%target_platform% >> build.sh
type "%RECIPE_DIR%\build.sh"                >> build.sh
set MSYSTEM=MINGW%ARCH%
set MSYS2_PATH_TYPE=inherit
set CHERE_INVOKING=1
FOR /F "delims=" %%i in ('cygpath.exe -u "%LIBRARY_PREFIX%"') DO set "PREFIX=%%i"
FOR /F "delims=" %%i in ('cygpath.exe -u "%BUILD_PREFIX%"') DO set "ac_cv_prog_PYTHON=%%i/python.exe"

set CC=cl.exe
set CXX=cl.exe

bash -lc "./build.sh"
if errorlevel 1 exit 1

:: The .dlls end up in the wrong place
move %LIBRARY_LIB%\icu*.dll %LIBRARY_BIN%
if errorlevel 1 exit 1
